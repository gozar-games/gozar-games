# GOZAR BATTLE ARENA — Asset Pack

## Ready for integration
- `maps/ruined-city.webp` — ruined grey city map
- `maps/desert-highway.webp` — desert highway map
- `maps/green-town.webp` — green town map
- `rewards/reward-chests.webp` — 3x3 reward chest sprite sheet (transparent background)
- `effects/combat-effects.webp` — orange/yellow combat effects sprite sheet (dark background keyed to alpha)

## Character references
The images in `reference/` are side-view characters / a roster. The current Battle Arena camera and soldier renderer are top-down/angled. These references are intentionally not wired as live character sprites because doing so would produce a mismatched orientation and animation. Keep the existing in-game soldier renderer until a matching top-down directional sprite sheet is prepared.

## Integration notes
The three map images are portrait backgrounds, not tile sets. They must be drawn with aspect-preserving scaling and camera-aware cropping. Collision geometry must be defined per map and tested separately; do not reuse the old procedural ruined-city collision grid on the new maps. The chest sheet is a 3x3 grid.

License: supplied by project owner, who confirmed permission to use these assets. Preserve any upstream attribution requirements if applicable.
